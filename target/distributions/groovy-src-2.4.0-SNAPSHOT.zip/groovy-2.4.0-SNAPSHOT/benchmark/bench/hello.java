// $Id: hello.java,v 1.3 2007-06-20 03:32:39 bfulgham Exp $
// http://shootout.alioth.debian.org/

public class hello {
    public static void main(String args[]) {
        System.out.print("hello world\n");
    }
}
