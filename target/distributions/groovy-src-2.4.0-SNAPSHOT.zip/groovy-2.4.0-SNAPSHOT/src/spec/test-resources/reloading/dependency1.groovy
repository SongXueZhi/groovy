class Dependency {
    String message = 'Hello, dependency 1'
}