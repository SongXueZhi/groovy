class Greeter {
    String sayHello() {
        def greet = "Hello, Groovy!"
        greet
    }
}


new Greeter()